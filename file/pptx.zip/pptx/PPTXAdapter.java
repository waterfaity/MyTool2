package com.waterfairy.document.pptx;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.waterfairy.utils.ImageUtils;
import com.waterfairy.utils.MD5Utils;

import net.pbdavey.awt.Graphics2D;

import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import and.awt.Dimension;

/**
 * Created by water_fairy on 2017/7/7.
 * 995637517@qq.com
 */

class PPTXAdapter extends BaseAdapter {
    private static final String TAG = "pptxAdapter";
    private Activity context;
    ;
    private int width;
    private XSLFSlide[] xslfSlides;
    private XMLSlideShow xmlSlideShow;
    private Dimension dimension;
    private String pptPath;
    final ExecutorService es = Executors.newSingleThreadExecutor();
    private String baseCacheImgPath;


    public PPTXAdapter(Activity context, String pptPath, XMLSlideShow xslfSlides, int width) {
        this.context = context;
        this.dimension = xslfSlides.getPageSize();
        this.xslfSlides = xslfSlides.getSlides();
        this.width = width;
        this.pptPath = pptPath;
        baseCacheImgPath = context.getExternalCacheDir().getPath() + "/img";
        Log.i(TAG, "PPTXAdapter: " + baseCacheImgPath);
    }

    @Override
    public int getCount() {
        if (xslfSlides == null) return 0;
        return xslfSlides.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = new RelativeLayout(context);
        }
        RelativeLayout linearLayout = (RelativeLayout) convertView;
        linearLayout.removeAllViews();
        final ImageView imageView = new ImageView(context);
        linearLayout.addView(imageView);
        final TextView loading = new TextView(context);
        loading.setText("加载中...");
        linearLayout.addView(loading);
        final int widthTemp = (int) dimension.getWidth();
        final int heightTemp = (int) dimension.getHeight();

        final XSLFSlide xslfSlide = xslfSlides[position];
        es.submit(new Runnable() {
            @Override
            public void run() {
////正常
//                Log.i(TAG, "run: 获取图片  ----");
//                final Bitmap bitmap = Bitmap.createBitmap(widthTemp, heightTemp, Bitmap.Config.RGB_565);
//                Canvas canvas = new Canvas(bitmap);
//                final Graphics2D graphics2D = new Graphics2D(canvas);
//                xslfSlide.draw(graphics2D, new AtomicBoolean(false), handler, position);
//                context.runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        Log.i(TAG, "run: 展示图  ----");
//                        imageView.setImageBitmap(bitmap);
//                        loading.setText("");
//                    }
//                });
//有保存

                Bitmap cacheBitmap = getCacheBitmap(position);
                Bitmap showBitmap = null;
                if (cacheBitmap == null) {
                    Log.i(TAG, "run: 获取图片中...");
                    showBitmap = Bitmap.createBitmap(widthTemp, heightTemp, Bitmap.Config.RGB_565);
                    Canvas canvas = new Canvas(showBitmap);
                    final Graphics2D graphics2D = new Graphics2D(canvas);
                    xslfSlide.draw(graphics2D, new AtomicBoolean(false),handler, position);
                    Log.i(TAG, "run: 获取图片");
                    final Bitmap finalBitmap = Bitmap.createBitmap(showBitmap);
                    new Thread() {
                        @Override
                        public void run() {
                            Log.i(TAG, "run: 保存图片");
                            ImageUtils.saveBitmap(getCachePath(position), finalBitmap);
                        }
                    }.start();
                } else {
                    Log.i(TAG, "run: 获取本地图片中...");
                    showBitmap = Bitmap.createBitmap(cacheBitmap);
                }
                final Bitmap showBitmapTempFinal = Bitmap.createBitmap(showBitmap);
                context.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.i(TAG, "run: 展示图片");
                        imageView.setImageBitmap(showBitmapTempFinal);
                        loading.setText("");
                    }
                });
            }
        });
        ViewGroup.LayoutParams layoutParams = imageView.getLayoutParams();
        imageView.setBackgroundColor(Color.WHITE);
        layoutParams.width = width;
        layoutParams.height = (int) ((float) heightTemp * width / widthTemp);
        imageView.setLayoutParams(layoutParams);
        RelativeLayout.LayoutParams layoutParams1 = (RelativeLayout.LayoutParams) loading.getLayoutParams();
        layoutParams1.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        loading.setLayoutParams(layoutParams1);
        return convertView;
    }

    private String getCachePath(int position) {
        return baseCacheImgPath + "/ppt/" + MD5Utils.getMD5Code(pptPath + "-" + position);
    }

    private Bitmap getCacheBitmap(int position) {
        File file = new File(getCachePath(position));
        if (file.exists()) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        } else {
            return null;
        }
    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
        }
    };
}
