package net.pbdavey.awt;

public class GraphicsEnvironment {

	public static boolean isHeadless() {
		// TODO Auto-generated method stub
		return false;
	}

}
