package and.awt;

import android.graphics.Bitmap;

public class Image {

	public static final String SCALE_SMOOTH = null;
	public Bitmap bm;
	
	public Image(Bitmap bm) {
		this.bm = bm;
	}
}
