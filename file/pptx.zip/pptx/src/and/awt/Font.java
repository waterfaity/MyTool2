package and.awt;

public class Font {

	public static final String PLAIN = null;
	public static final int ROMAN_BASELINE = 0;
	public static final int CENTER_BASELINE = 0;
	public static final int HANGING_BASELINE = 0;

	public Font(String fontName, String plain2, int i) {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isPlain() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isBold() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isItalic() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean canDisplay(char bulletChar) {
		// TODO Auto-generated method stub
		return false;
	}

}
